package com.focus.stylesexample.app;

import android.content.Context;
import android.widget.EditText;

/**
 * Created by J.yugandhar on 06-07-2016.
 */
public class CLEditText extends EditText {
    public CLEditText(Context context) {
        super(context);
    }
}
