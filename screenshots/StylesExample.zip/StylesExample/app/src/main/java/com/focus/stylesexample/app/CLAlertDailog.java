package com.focus.stylesexample.app;

import android.app.ActionBar;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Icon;
import android.os.Bundle;
import android.support.v4.widget.ContentLoadingProgressBar;
import android.util.TypedValue;
import android.view.*;
import android.widget.*;

/**
 * Created by J.yugandhar on 05-07-2016.
 */
public class CLAlertDailog extends Dialog {

    Context mContext;
    String sMessage=null;
    String sTitle=null;
    protected CLAlertDailog(Context context, boolean cancelable, OnCancelListener cancelListener,String title,String Message) {
        super(context, cancelable, cancelListener);
        this.mContext=context;
        this.sMessage=Message;
        this.sTitle=title;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(setDailogView());
        getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);




    }

    public void setInfo()
    {

    }

    private View setDailogView()
    {

        LinearLayout CLMainLayout=new LinearLayout(mContext);

        CLMainLayout.setBackgroundColor(Color.WHITE);
       // CLMainLayout.setGravity(Gravity.CENTER);
        CLMainLayout.setOrientation(LinearLayout.VERTICAL);


        LinearLayout CLTiltleLayout=new LinearLayout(mContext);
        LinearLayout.LayoutParams tileLayoutParms=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tileLayoutParms.setMargins(5, 5, 5, 5);
        CLTiltleLayout.setOrientation(LinearLayout.HORIZONTAL);
        CLTiltleLayout.setLayoutParams(tileLayoutParms);

        ImageView icon=new ImageView(mContext);
        icon.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        icon.setBackgroundResource(android.R.drawable.ic_dialog_alert);

        TextView CLTitleText=new TextView(mContext);
        LinearLayout.LayoutParams titleParms=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        titleParms.setMargins(10, 10, 10, 10);
        CLTitleText.setLayoutParams(titleParms);
        CLTitleText.setTextColor(Color.parseColor("#00BCD4"));
        CLTitleText.setText(sTitle);
        CLTitleText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);

        CLTiltleLayout.addView(icon);
        CLTiltleLayout.addView(CLTitleText);
        LinearLayout titleline=new LinearLayout(mContext);
        LinearLayout.LayoutParams lineparms=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,2);
        lineparms.setMargins(0, 5, 0, 5);
        titleline.setLayoutParams(lineparms);
        titleline.setBackgroundColor(Color.parseColor("#00BCD4"));

        TextView CLMessageText=new TextView(mContext);
        LinearLayout.LayoutParams msgParms=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        msgParms.setMargins(10, 10, 10, 10);
        CLMessageText.setLayoutParams(msgParms);
        CLMessageText.setText(sMessage);
        CLMessageText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);

        LinearLayout msgLine=new LinearLayout(mContext);
        LinearLayout.LayoutParams msgLineParms=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,1);
//        msgLineParms.setMargins(5, 5, 5, 5);
        msgLine.setLayoutParams(msgLineParms);
        msgLine.setBackgroundColor(Color.LTGRAY);

        Button CLbutton=new Button(mContext);
        LinearLayout.LayoutParams buttonParms=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        buttonParms.setMargins(5, 5, 5, 5);
        CLbutton.setLayoutParams(buttonParms);
        CLbutton.setText("Ok");
        CLbutton.setBackgroundColor(Color.TRANSPARENT);


    /*    CLMainLayout.addView(CLTitleText);
        CLMainLayout.addView(titleline);*/
        CLMainLayout.addView(CLTiltleLayout);
        CLMainLayout.addView(CLMessageText);
        CLMainLayout.addView(msgLine);
        CLMainLayout.addView(CLbutton);

        CLbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dismiss();
            }
        });


        return CLMainLayout;
    }
}
