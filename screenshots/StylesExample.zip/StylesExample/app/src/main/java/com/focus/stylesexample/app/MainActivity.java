package com.focus.stylesexample.app;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.*;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout mainLayout=new LinearLayout(this);
        LinearLayout.LayoutParams lprams=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
        lprams.setMargins(10, 10, 10, 10);
        mainLayout.setLayoutParams(lprams);
        mainLayout.setBackgroundColor(Color.WHITE);
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        mainLayout.setGravity(Gravity.CENTER_HORIZONTAL);

        LinearLayout.LayoutParams btparms = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        btparms.setMargins(5,5,5,5);
        EditText et=new EditText(this);
        et.setLayoutParams(btparms);

        et.setHint("enter name");

        TextView text=new TextView(this);
        text.setLayoutParams(btparms);
        text.setText("text view");

        ProgressBar pb=new ProgressBar(this);

        CheckBox cb=new CheckBox(this);
        cb.setLayoutParams(btparms);
        cb.setText("check box");

        RadioButton rb=new RadioButton(this);
        rb.setLayoutParams(btparms);
        rb.setText("radio button");

        ToggleButton tg=new ToggleButton(this);
        tg.setLayoutParams(btparms);

        Spinner spinner=new Spinner(this);
        spinner.setLayoutParams(btparms);


        Button btone=new Button(this);
        btone.setLayoutParams(btparms);
        btone.setText("Butoon");
      /*  GradientDrawable drawable = (GradientDrawable) btone
                .getBackground();
        drawable.setColor(this.getResources().getColor(
                R.color.custome_accent));*/
        mainLayout.addView(et);
        mainLayout.addView(text);
        mainLayout.addView(pb);
        mainLayout.addView(cb);
        mainLayout.addView(rb);
        mainLayout.addView(tg);
        mainLayout.addView(spinner);
        mainLayout.addView(btone);

        setContentView(mainLayout);
// Application of the Array to the Spinner
        ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(this,   android.R.layout.simple_spinner_item, getResources().getStringArray(R.array.countries));
        spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); // The drop down view
        spinner.setAdapter(spinnerArrayAdapter);
    }



}
