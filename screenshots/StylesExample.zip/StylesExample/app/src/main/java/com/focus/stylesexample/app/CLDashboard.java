package com.focus.stylesexample.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;

/**
 * Created by J.yugandhar on 04-07-2016.
 */
public class CLDashboard extends AppCompatActivity {

    Button theme,customeTheame,progress,sweetAlert,toolbar,showcase,search,snackbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        LinearLayout.LayoutParams parms = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        parms.setMargins(5, 5, 5, 5);
        layout.setOrientation(LinearLayout.VERTICAL);

        LinearLayout.LayoutParams butParms = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        butParms.setMargins(5, 5, 5, 5);

        theme = new Button(this);
        theme.setText("validation");
        theme.setLayoutParams(butParms);

        customeTheame = new Button(this);
        customeTheame.setText("customeTheame");
        customeTheame.setLayoutParams(butParms);

   /*     progress = new Button(this);
        progress.setText("Progress Example");
        progress.setLayoutParams(butParms);

        sweetAlert = new Button(this);
        sweetAlert.setText("sweeALert Example");
        sweetAlert.setLayoutParams(butParms);
        */

        layout.addView(theme);
        layout.addView(customeTheame);
        setContentView(layout);

        theme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(CLDashboard.this, EditTextValidation.class);
                startActivity(i);
            }
        });
        customeTheame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(CLDashboard.this,CustomeActivity.class);
                startActivity(i);
            }
        });

    }
    }
