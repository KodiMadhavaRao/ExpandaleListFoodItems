package com.focus.stylesexample.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RectShape;
import android.widget.Button;

/**
 * Created by J.yugandhar on 06-07-2016.
 */
public class CLButton extends Button {
    public CLButton(Context context) {
        super(context);
    }

    public ShapeDrawable setBackground(int fillcolor,int strockcolor)
    {
        int strokeWidth = 5; // 3px not dp
        int roundRadius = 15; // 8px not dp
//        int strokeColor = Color.parseColor("#2E3135");
//        int fillColor = Color.parseColor("#DFDFE0");
/*
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(fillcolor);
        gd.setCornerRadius(roundRadius);
        gd.setStroke(strokeWidth, strockcolor);*/
        ShapeDrawable shape = new ShapeDrawable(new RectShape());
        shape.getPaint().setColor(Color.RED);
        shape.getPaint().setStyle(Paint.Style.STROKE);
        shape.getPaint().setStrokeWidth(3);
       return shape;
    }
}
