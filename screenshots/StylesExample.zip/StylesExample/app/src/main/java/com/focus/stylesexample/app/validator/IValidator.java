package com.focus.stylesexample.app.validator;

/**
 * Created by nagababu on 01-07-2016.
 */
public interface IValidator
{
     interface  IValidateType
    {
        public static final byte MANDATORY = 1;
        public static final byte VALID = 2;
        public static final byte DATE_RANGE = 3;
        public static final byte TIME_RANGE = 4;
    }

}
