package com.focus.stylesexample.app;

import java.util.Calendar;
import java.util.Date;

import com.focus.stylesexample.app.validator.IConstants;

/**
 * Created by nagababu on 04-07-2016.
 */
public class CLUtil
{
    public static String[] parseTime(String sTime)
    {
        String  []sArrTime = sTime.split(":");
        String []sTimePart = sArrTime[1].split(" ");

        if(sTimePart.length>1)
        {
            if(sTimePart[1].equalsIgnoreCase("PM"))
            {
                if(sArrTime[0].equalsIgnoreCase("12"))
                    sArrTime[0]= String.valueOf(Integer.parseInt(sArrTime[0],10)+12);
            }
            else if(sArrTime[0].equalsIgnoreCase("12"))
                sArrTime[0]="0";
            sArrTime[1]=sTimePart[0];
        }

        return sArrTime;
    }
    public static int getTimeDiff(Calendar clStartDateCal,Calendar clEndDateCal)
    {
        return (int)((clEndDateCal.getTime().getTime() - clStartDateCal.getTime().getTime())) / (1000*60);
    }
    public  static String getDateSeparator(byte byFormat)
{
    switch(byFormat)
    {
        case IConstants.IDateFormat.DDMMYYYY:
        case IConstants.IDateFormat.MMDDYYYY:
        case IConstants.IDateFormat.YYYYMMDD:
        case IConstants.IDateFormat.DDMMYY:
            return "/";
        case IConstants.IDateFormat.DD_MM_YYYY:
        case IConstants.IDateFormat.DD_MM_YY:
        case IConstants.IDateFormat.MM_DD_YYYY:
        case IConstants.IDateFormat.YYYY_MM_DD:
        case IConstants.IDateFormat.DD_MON_YY:
        case IConstants.IDateFormat.DD_MON_YYYY:
            return "-";
        case IConstants.IDateFormat.DD__MON__YYYY:
        case IConstants.IDateFormat.DD__MON__YY:
            return " ";
        case IConstants.IDateFormat.DD____MM____YYYY:
        case IConstants.IDateFormat.DD____MM____YY:
        case IConstants.IDateFormat.MM____DD____YYYY:
            return "\\";
        default:
            return "/";
    }
}
    public  static String[] parseDate(String sDate,byte byFormat,boolean isDateTime)
{
/*    if(!iFormat)
        iFormat=clAppBuffer.getDateFormat();
    iFormat=parseInt(iFormat,10);*/
    if(isDateTime)
        sDate=sDate.substring(0,sDate.indexOf(" "));

    String []sArrReturnDate=sDate.split(getDateSeparator(byFormat));

    switch(byFormat)
    {
        case IConstants.IDateFormat.DDMMYYYY:
        case IConstants.IDateFormat.DD_MM_YYYY:
        {
            return sArrReturnDate;
        }
        case IConstants.IDateFormat.MMDDYYYY:
        case IConstants.IDateFormat.MM_DD_YYYY:
            return new String [] {sArrReturnDate[1],sArrReturnDate[0],sArrReturnDate[2]};
        case IConstants.IDateFormat.YYYYMMDD:
        case IConstants.IDateFormat.YYYY_MM_DD:
            return new String [] {sArrReturnDate[2],sArrReturnDate[1],sArrReturnDate[0]};
        default:
        {
            return sArrReturnDate;
        }
    }
}
    public static Date getDateObject(String sDate,boolean isDateTime,boolean isSetTime)
{
    Calendar clCalendar = Calendar.getInstance();
    /*if(sDate == null)
        sDate=clAppBuffer.getTodaysDateAsString();*/

    if(sDate != null && sDate.trim().length() > 0)
    {
        String []sArrDate = parseDate(sDate,(byte)0,isDateTime);

        clCalendar.set(Calendar.DATE,1);
        clCalendar.set(Calendar.MONTH,Integer.parseInt(sArrDate[1],10)-1);
        clCalendar.set(Calendar.YEAR,Integer.parseInt(sArrDate[2]));
        clCalendar.set(Calendar.DATE,Integer.parseInt(sArrDate[0]));


        if(isDateTime)
        {
            if(isSetTime)
            {
                String []sArrTime = parseTime(sDate.substring(sDate.indexOf(" ")+1));
                clCalendar.set(Calendar.HOUR_OF_DAY,Integer.parseInt(sArrTime[0]));
                clCalendar.set(Calendar.MINUTE,Integer.parseInt(sArrTime[1]));
            }
            else
            {
                clCalendar.set(Calendar.HOUR_OF_DAY,0);
                clCalendar.set(Calendar.MINUTE,0);
            }
        }
    }
    return clCalendar.getTime();
};
    /**
     * This method returns day count between startdate and endate. For same dates it will return zero
     * @param clStartDateCal
     * @param clEndDateCal
     */
public static int  getDateDiff(Date clStartDateCal,Date clEndDateCal)
{
    return (int)((clEndDateCal.getTime() - clStartDateCal.getTime())) / (1000*60*60*24); //86400000;

}


}
