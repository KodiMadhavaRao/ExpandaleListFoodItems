package com.focus.stylesexample.app;

import android.app.Activity;
import android.app.Application;
import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.*;
import com.focus.stylesexample.app.validator.CLValidator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by J.yugandhar on 29-06-2016.
 */
public class EditTextValidation extends AppCompatActivity {

    EditText etWebsite,etmobileno,etEmail;
    LinearLayout mainLyout;
    Snackbar snack;
    Animation snackbarAnimation;
    Animation shake;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

         mainLyout=new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT);
        layoutParams.setMargins(5, 5, 5, 5);
        mainLyout.setLayoutParams(layoutParams);
        mainLyout.setOrientation(LinearLayout.VERTICAL);

        LinearLayout.LayoutParams txtinputparms=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
         txtinputparms.setMargins(5, 5, 5, 5);

        etWebsite=new EditText(this);
        etWebsite.setLayoutParams(txtinputparms);
        etWebsite.setHint("enter website");

        etmobileno=new EditText(this);
        etmobileno.setLayoutParams(txtinputparms);
        etmobileno.setInputType(InputType.TYPE_CLASS_NUMBER);
        etmobileno.setHint("enter mobile no");

        etEmail=new EditText(this);
        etEmail.setLayoutParams(txtinputparms);
        etEmail.setHint("enter email");

//        Snackbar sb=new Snackbar(this);


        Button btone=new Button(this);
        LinearLayout.LayoutParams btparms=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        btparms.setMargins(5,5,5,5);
        btone.setLayoutParams(btparms);
        btone.setText("Next");

        snackbarAnimation = AnimationUtils.loadAnimation(EditTextValidation.this, R.anim.up_from_bottom);

        mainLyout.addView(etEmail);
        mainLyout.addView(etWebsite);
        mainLyout.addView(etmobileno);

        mainLyout.addView(btone);
        setContentView(mainLyout);
        getSnackBar();

//        shake = AnimationUtils.loadAnimation(this, R.anim.shakeanim);
        btone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                CLValidator.getInstance().checkMandatory(etEmail,"Field should not be empty");
                CLValidator.getInstance().checkEMail(etEmail, "InValidEmial");
                CLValidator.getInstance().checkPhoneNo(etmobileno, "invalid Mobile number");
               if(! CLValidator.getInstance().checkWebsite(etWebsite, "not a valid website",true))
               {
                   if(!(snack!=null && snack.isShown()))
                   snack.show();
               }
                /*final String email = etEmail.getText().toString();
                if (!isValidEmail(email)) {
//                    etEmail.setError("Invalid Email");
                    etEmail.setError(Html.fromHtml("<font color='gray'>Invalid Email</font>"));
//                    etEmail.startAnimation(shake);
                }
                final String pass = etPassword.getText().toString();
                if (!isValidPassword(pass)) {

//                    etPassword.setError("Invalid Password");
                    etPassword.setError(Html.fromHtml("<font color='gray'>Invalid Password </font>"));
//                    etPassword.startAnimation(shake);
                }

                final  String uname=etUserName.getText().toString();
                if(!isValidUserName(uname))
                {
                   // etUserName.setError("Invaild userName");
                    etUserName.setError(Html.fromHtml("<font color='gray'>Invalid userName</font>"));
//                    etUserName.startAnimation(shake);
                }*/
            }
        });

    }
  private void getSnackBar()
  {
      snack = Snackbar.make(mainLyout, "web site is manditory", Snackbar.LENGTH_INDEFINITE);
      View view = snack.getView();
      FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
      params.gravity = Gravity.TOP|Gravity.CENTER;
      params.setMargins(0, 0, 0, 0);
      view.setLayoutParams(params);
      view.setBackgroundColor(getResources().getColor(R.color.green_primarydark));
      TextView tv = (TextView) view.findViewById(android.support.design.R.id.snackbar_text);
      tv.setTextColor(Color.WHITE);
      view.startAnimation(snackbarAnimation);
      snack.setAction("okay", new View.OnClickListener() {
          @Override
          public void onClick(View view) {
              snack.dismiss();
          }
      });
  }
}
