package com.focus.stylesexample.app.validator;

/**
 * Created by nagababu on 01-07-2016.
 */
public interface IConstants
{

    interface ITimeFormat
    {
        public static final byte  TIME_HH_MM = 1;
        public static final byte  TIME_HH_MM_AM_PM = 2;
        public static final byte  TIME_HH_MM_SS = 3;
        public static final byte  TIME_HH_MM_SS_AM_PM = 4;
    }
    interface IControlType
    {
        public static final byte TXT_BOX = 0;
        public static final byte SPIN_CTRL = 1;
        public static final byte COMBO_BOX = 2;
        public static final byte RADIO_BUTTON = 3;
        public static final byte OPTION_CTRL = 4;
        public static final byte DATE_PICKER = 5;
        public static final byte TIME_PICKER = 6;
        public static final byte DOCUMENT_CTRL = 7;
        public static final byte PICTURE_BOX = 8;
        public static final byte CHECKBOX = 9;
        public static final byte SLIDER_CTRL = 10;
        public static final byte COMPOSITE_FLD = 11;
        public static final byte PHONE = 12;
        public static final byte EMAIL = 13;
        public static final byte WEBSITE = 14;
        public static final byte COLOR_PICKER = 15;
        public static final byte BUTTON = 16;
        public static final byte APPROVAL_STATUS= 51;
        public static final byte MULTI_SELECT = 52;
        public static final byte RADIO_WITH_IMAGE = 56;
        public static final byte DURATION = 57;


    }
    interface IDateFormat
    {
        public static final byte DDMMYYYY = 0;/// as 20/2/YYYY
        public static final byte MMDDYYYY = 1;/// as 02/20/YYYY
        public static final byte YYYYMMDD = 2;// as  YYYY/02/20

        public static final byte DD_MM_YYYY = 3;/// as 20-2-YYYY
        public static final byte MM_DD_YYYY = 4;// as 02-20-YYYY
        public static final byte YYYY_MM_DD = 5;//as YYYY-02-20

        public static final byte DD___MM___YYYY = 6;// as 0705YYYY
        public static final byte MM___DD___YYYY = 7;// as 0507YYYY
        public static final byte YYYY___MM___DD = 8;// as YYYY0705

        public static final byte DDMMYY = 9;/// as 20/2/YY
        public static final byte MMDDYY = 10;/// as 02/20/YY
        public static final byte YYMMDD = 11;/// as YY/02/12

        public static final byte DD_MM_YY = 12;/// as 20-02-07
        public static final byte MM_DD_YY = 13;/// as 02-20-07
        public static final byte YY_MM_DD = 14;/// as 07-02-17

        public static final byte DD___MM___YY = 15; // as 070522
        public static final byte MM___DD___YY = 16; // as 220507
        public static final byte YY___MM___DD = 17; // as 220507

        public static final byte DD____MM____YYYY = 18;/// as 07\05\YYYY
        public static final byte MM____DD____YYYY = 19;/// as 02\20\YYYY
        public static final byte YYYY____MM____DD = 20;/// as YYYY\02\20

        public static final byte DD____MM____YY = 21; /// as 07\05\yy
        public static final byte MM____DD____YY = 22; /// as 05\07\yy
        public static final byte YY____MM____DD = 23; /// as yy\07\05

        public static final byte DDMONYYYY = 24; /// as 20/jun/YYYY
        public static final byte DDMONYY = 25; /// as 20/jun/07

        public static final byte DD_MON_YYYY = 26;/// as 20-jun-YYYY
        public static final byte DD_MON_YY = 27;/// as 20-jun-07

        public static final byte DD___MON___YYYY = 28; /// as 20junYYYY
        public static final byte DD___MON___YY = 29; /// as 20jun07

        public static final byte DD__MON__YYYY = 30;/// as 20 jun YYYY
        public static final byte DD__MON__YY = 31;/// as 20 jun 07

        public static final byte MON__DD__YYYY__TIME_HHMMAMPM = 51;/// as Oct 13, 2011 11:59 AM,

    }
}
