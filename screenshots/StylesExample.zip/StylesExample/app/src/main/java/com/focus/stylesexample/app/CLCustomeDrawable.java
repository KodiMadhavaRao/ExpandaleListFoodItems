package com.focus.stylesexample.app;

import android.graphics.drawable.GradientDrawable;
import android.view.View;

/**
 * Created by J.yugandhar on 06-07-2016.
 */
public class CLCustomeDrawable  {

    public static GradientDrawable customView(View v, int backgroundColor, int borderColor)
    {
        GradientDrawable shape = new GradientDrawable();
        shape.setShape(GradientDrawable.RECTANGLE);
        shape.setCornerRadii(new float[] { 10, 10, 10, 10, 10, 10, 10, 10 });
        shape.setColor(backgroundColor);
        shape.setStroke(1,borderColor);
        v.setBackgroundDrawable(shape);
        return shape;
    }
}
