package com.focus.stylesexample.app;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.TransitionDrawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import com.focus.stylesexample.app.validator.CLValidator;

/**
 * Created by J.yugandhar on 04-07-2016.
 */
public class CustomeActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout mainLayout=new LinearLayout(this);
        LinearLayout.LayoutParams lprams=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
        lprams.setMargins(10, 10, 10, 10);
        mainLayout.setLayoutParams(lprams);
        mainLayout.setId(R.id.main_layout);
        mainLayout.setBackgroundColor(Color.WHITE);
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        mainLayout.setGravity(Gravity.CENTER_HORIZONTAL);

        Typeface iconFont = CLFontManager.getTypeface(getApplicationContext(), CLFontManager.FONTAWESOME);
        CLFontManager.markAsIconContainer(findViewById(R.id.main_layout), iconFont);
        LinearLayout.LayoutParams btparms=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        btparms.setMargins(5, 5, 5, 5);

        CLEditText et=new CLEditText(this);

        et.setLayoutParams(btparms);
//        et.setHeight(50);
        et.setHint("enter name");

        TextView text=new TextView(this);
//        text.setLayoutParams(btparms);
//        text.setText("text view");

      //  TextView pendingImage=new TextView(this);
        //pendingImage.setId(R.id.pending_image);
        CLFontManager.markAsIconContainer(text, iconFont);
        text.setText(R.string.fa_icon_linechart);
        text.setTextSize(45);
        text.setTextColor(getResources().getColor(R.color.green_primary));

        ProgressBar pb=new ProgressBar(this);

        CheckBox cb=new CheckBox(this);
        cb.setLayoutParams(btparms);
        cb.setText("check box");

        RadioButton rb=new RadioButton(this);
        rb.setLayoutParams(btparms);
        rb.setText("radio button");
        LinearLayout.LayoutParams tgleParms=new LinearLayout.LayoutParams(80, 50);
        tgleParms.setMargins(5, 5, 5, 5);
        ToggleButton tg=new ToggleButton(this);
//        CLFontManager.markAsIconContainer(tg, iconFont);
        tg.setLayoutParams(tgleParms);
//        tg.setText(R.string.fa_icon_toggleoff);

        Spinner spinner = new Spinner(this);
        spinner.setLayoutParams(btparms);


        CLButton btone=new CLButton(this);
        btone.setLayoutParams(btparms);
//        btone.setBackground(getResources().getColor(R.color.colorPrimary),getResources().getColor(R.color.green_primarylite));
        btone.setText("Button");
        btone.setBackgroundDrawable(CLCustomeDrawable.customView(btone, getResources().getColor(R.color.green_primary), getResources().getColor(R.color.green_primary)));
        /*Drawable bgShape = btone.getBackground();
        bgShape.setColorFilter(Color.YELLOW, PorterDuff.Mode.LIGHTEN);*/
        mainLayout.addView(et);
        mainLayout.addView(text);
//        mainLayout.addView(pb);
        mainLayout.addView(cb);
        mainLayout.addView(rb);
        mainLayout.addView(tg);
        mainLayout.addView(spinner);
        mainLayout.addView(btone);

        setContentView(mainLayout);


       // Application of the Array to the Spinner
        ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(this,   android.R.layout.simple_spinner_item, getResources().getStringArray(R.array.countries));
        spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); // The drop down view
        spinner.setAdapter(spinnerArrayAdapter);


        btone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CLAlertDailog clDailog=new CLAlertDailog(CustomeActivity.this,true,null,"Warning","Do you really  want to Close");
//                clDailog.setTitle("Warning");
                clDailog.show();
            }
        });
    }

}
