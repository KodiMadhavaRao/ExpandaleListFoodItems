package com.focus.stylesexample.app.validator;

import java.io.Serializable;

/**
 * Created by nagababu on 04-07-2016.
 */
public class CLValidateFieldDTO implements Serializable
{
    byte byValidateType;
    byte byEventType;
    byte byControlType;
    int iFieldId;

    public byte getValidateType() {
        return byValidateType;
    }

    public void setValidateType(byte byValidateType) {
        this.byValidateType = byValidateType;
    }

    public byte getEventType() {
        return byEventType;
    }

    public void setEventType(byte byEventType) {
        this.byEventType = byEventType;
    }

    public byte getControlType() {
        return byControlType;
    }

    public void setControlType(byte byControlType) {
        this.byControlType = byControlType;
    }

    public int getFieldId() {
        return iFieldId;
    }

    public void setFieldId(int iFieldId) {
        this.iFieldId = iFieldId;
    }
}
