package com.focus.stylesexample.app.validator;


import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.focus.stylesexample.app.CLUtil;


import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.regex.Pattern;


/**
 * Created by nagababu on 01-07-2016.
 */
public class CLValidator
{
    private static CLValidator clValidator = null;
    private static HashMap<Integer,CLValidateFieldDTO> hsValidateFields = null;
    public static CLValidator getInstance()
    {
        if(clValidator == null) {
            clValidator = new CLValidator();
            hsValidateFields = new HashMap<Integer,CLValidateFieldDTO>();
        }
        return clValidator;
    }
    public static boolean checkMandatory(TextView clTextView,String sMsg)
    {
        return checkMandatory(clTextView, sMsg, false);
    }
    public static boolean checkMandatory(TextView clTextView,String sMsg,boolean isGlobalMsg)
    {
        boolean bValid = true;
        if(clTextView != null)
        {
            if(clTextView.getText() != null)
                bValid = trim(clTextView.getText().toString()).length() > 0;
            if (!bValid)
                setError(clTextView, IValidator.IValidateType.MANDATORY,sMsg,isGlobalMsg);
        }

        return bValid;
    }
    public static boolean checkDate(TextView clTextView,String sMsg)
    {
        return checkDate(clTextView,sMsg,false);
    }
    public static boolean checkDate(TextView clTextView,String sMsg,boolean isGlobalMsg)
    {
        boolean bValid = checkMandatory(clTextView,sMsg);
        if(bValid)
        {
            bValid = checkPattern("/^(((0?[1-9]|[12]\\d|3[01])\\/(0?[13578]|1[02])\\/((19|[2-9]\\d)\\d{2}))|((0?[1-9]|[12]\\d|30)\\/(0?[13456789]|1[012])\\/((19|[2-9]\\d)\\d{2}))|((0?[1-9]|1\\d|2[0-8])\\/02\\/((19|[2-9]\\d)\\d{2}))|(29\\/02\\/((1[6-9]|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|((16|[2468][048]|[3579][26])00))))$/",clTextView.getText().toString());
            if(!bValid)
                setError(clTextView,IValidator.IValidateType.VALID,sMsg,isGlobalMsg);
        }
        return bValid;
    }
    public static boolean checkDateRange(TextView clTextView1, TextView clTextView2,
                                         String sLabel1,String sLabel2,
                                         String sMsg, byte byDateFormat,
                                         boolean isDateTime,boolean isAllowEqualDates,boolean isAllowEqualTimes,boolean isGlobalMsg)

    {
        boolean bValid = false;
        if(checkMandatory(clTextView1,null)
                && checkMandatory(clTextView2,null))
        {
            String sStartDate = clTextView1.getText().toString();
            String sEndDate = clTextView2.getText().toString();
            String sSeparator = CLUtil.getDateSeparator(byDateFormat);
            if(isDateTime)
            {
                sStartDate = sStartDate.substring(0, sStartDate.indexOf(" "));
                sEndDate = sEndDate.substring(0, sEndDate.indexOf(" "));
            }
            Date dStartDate = CLUtil.getDateObject(sStartDate,isDateTime,false);
            Date  dEndDate = CLUtil.getDateObject(sEndDate,isDateTime,false);
            int iNoOfDays = CLUtil.getDateDiff(dStartDate, dEndDate);

            if(isAllowEqualDates)
                iNoOfDays++;
            if (iNoOfDays >= 1)  //to overcome fraction values(eg: 0.00343), checking with value '1'
                bValid = true;

            if(bValid && iNoOfDays == 1 && isDateTime)// && isDateTime)
                bValid  = checkTimeRange(clTextView1,clTextView2,sLabel1,sLabel2,sMsg,(byte)0,isDateTime,isAllowEqualTimes,isGlobalMsg);
        }
        else
            bValid = false;
        if(!bValid)
        {
            if(sMsg == null || trim(sMsg).length() > 0)
                sMsg = getComparisonMsg(sLabel1,sLabel2,isAllowEqualDates);
            setError(clTextView1, IValidator.IValidateType.VALID, sMsg, isGlobalMsg);//todo
        }
        return bValid;
    }
    public static boolean checkTime(TextView clTextView,byte byTimeFormat ,String sMsg,boolean isIncSeconds)
    {
        return checkTime(clTextView,byTimeFormat,sMsg,isIncSeconds,false);
    }
    public static boolean checkTime(TextView clTextView,byte byTimeFormat,String sMsg,boolean isIncSeconds,boolean isGlobalMsg)
    {
        boolean bValid = checkMandatory(clTextView,sMsg);
        if(bValid)
        {
           // byte byTimeFormat = IConstants.ITimeFormat.TIME_HH_MM;
            String sPattern = null;
            if (isIncSeconds
                    || (byTimeFormat== IConstants.ITimeFormat.TIME_HH_MM_SS_AM_PM
                    ||byTimeFormat==IConstants.ITimeFormat.TIME_HH_MM_SS))
            {
                //sPattern = /(^(0?[1-9]|1[0-2]):[0-5][0-9]:[0-5][0-9]\s?([ap]m|[AP]M)$)|(^([01]\d|2[0-3])(:[0-5]\d){0,2}$)/;
                if(byTimeFormat == IConstants.ITimeFormat.TIME_HH_MM_SS_AM_PM)
                    sPattern = "/(^(0?[0-9]|1[0-2]):[0-5][0-9]:[0-5][0-9]\\s?([ap]m|[AP]M)$)/";
                else// if(iTimeFormat==Constants.TIME_HHMMSS)
                    sPattern = "/(^(0?\\d|1\\d|2[0-3])(:[0-5]\\d){0,2}:[0-5][0-9]$)/";

                bValid = checkPattern(sPattern,clTextView.getText().toString());
            }
            else

            {

                if(byTimeFormat == IConstants.ITimeFormat.TIME_HH_MM_AM_PM)
                    sPattern = "/^(0?[0-9]|1[0-2]):[0-5][0-9]\\s?([ap]m|[AP]M)$/";
                else// if(iTimeFormat==Constants.TIME_HHMM)
                    sPattern = "/(^(0?\\d|1\\d|2[0-3])(:[0-5]\\d){0,2}$)/";

                bValid = checkPattern(sPattern,clTextView.getText().toString());

                if(!bValid)
                {
                    setError(clTextView, IValidator.IValidateType.VALID,sMsg,isGlobalMsg);
                   /* if(!isAllowZero)
                        isValid=dateUtils.getTimeInMins(elemTime.value)>0;*/
                }

            }
        }

        return bValid;
    }
    public static boolean checkTimeRange(TextView clTextView1,TextView clTextView2,String sLabel1,String sLabel2,String sMsg,
                                         byte byTimeFormat,boolean isDateTimeField,
                                         boolean isAllowEqualTimes,boolean isGlobalMsg)
    {
        boolean bValid = false;
        if(checkMandatory(clTextView1,null)
                &&  checkMandatory(clTextView2,null))
        {
            String sTime = clTextView1.getText().toString();
            if (isDateTimeField)
                sTime = sTime.substring(sTime.indexOf(" ") + 1);
            String[] arrTime = CLUtil.parseTime(sTime);
            Calendar clStartDateCal = Calendar.getInstance();
            clStartDateCal.set(Calendar.HOUR_OF_DAY, Integer.parseInt(arrTime[0]));
            clStartDateCal.set(Calendar.MINUTE, Integer.parseInt(arrTime[1]));

            sTime = clTextView2.getText().toString();
            if (isDateTimeField)
                sTime = sTime.substring(sTime.indexOf(" ") + 1);

            arrTime = CLUtil.parseTime(sTime);
            Calendar clEndDateCal = Calendar.getInstance();
            clEndDateCal.set(Calendar.HOUR_OF_DAY, Integer.parseInt(arrTime[0]));
            clEndDateCal.set(Calendar.MINUTE, Integer.parseInt(arrTime[1]));


            int iTimeDiff = CLUtil.getTimeDiff(clEndDateCal, clEndDateCal);
            //alert("iTimeDiff  "+iTimeDiff);

            if (isAllowEqualTimes)
                iTimeDiff++;

            if (iTimeDiff >= 1)
                bValid = true;
            else
            {
                if(sMsg == null || trim(sMsg).length() > 0)
                    sMsg = getComparisonMsg(sLabel1,sLabel2,isAllowEqualTimes);
                setError(clTextView1, IValidator.IValidateType.VALID, sMsg, isGlobalMsg); // todo:
            }


        }
        return bValid;
    }
    public static boolean checkEMail(TextView clTextView,String sMsg)
    {
        return checkEMail(clTextView,sMsg,false);
    }
    public static boolean checkEMail(TextView clTextView,String sMsg,boolean isGlobalMsg)
    {
        boolean bValid = checkMandatory(clTextView,null);
        if(bValid)
        {

            bValid = checkPattern("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@" + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$",clTextView.getText().toString());
            if(!bValid)
                setError(clTextView,IValidator.IValidateType.VALID,sMsg,isGlobalMsg);
        }

        return bValid;
    }
    public static boolean checkPhoneNo(TextView clTextView,String sMsg)
    {

        return checkPhoneNo(clTextView,sMsg,false);
    }
    public static boolean checkPhoneNo(TextView clTextView,String sMsg,boolean isGlobalMsg)
    {
        boolean bValid = checkMandatory(clTextView,sMsg);
        if(!bValid)
            setError(clTextView,IValidator.IValidateType.VALID,sMsg,isGlobalMsg);
        return bValid;
    }
    public static boolean checkMobileNo(TextView clTextView,String sMsg)
    {
        return checkMobileNo(clTextView,sMsg,false);
    }
    public static boolean checkMobileNo(TextView clTextView,String sMsg,boolean isGlobalMsg)
    {
        boolean bValid = checkMandatory(clTextView,sMsg);
        if(bValid)
        {
            bValid = checkPattern("/^((\\+)91(\\s)?(\\-)?(\\s)?)?[0-9]{1}[0-9]{9}$/",clTextView.getText().toString());
            if(!bValid)
                setError(clTextView,IValidator.IValidateType.VALID,sMsg,isGlobalMsg);
        }

        return bValid;
    }
    public static boolean checkWebsite(TextView clTextView,String sMsg)
    {
        return checkWebsite(clTextView,sMsg,false);
    }
    public static boolean checkWebsite(TextView clTextView,String sMsg,boolean isGlobalMsg)
    {

        boolean bValid = checkMandatory(clTextView,sMsg);
        if(bValid)
        {
            bValid = checkPattern("/^(((ht|f){1}(tp[s]{0,1}:[/][/]){1}){0,1}((www.){1}))[-a-zA-Z0-9@:%_\\+~#?&//=]+([.]{1}[a-zA-Z]+)$/",clTextView.getText().toString());
            if(!bValid)
                setError(clTextView,IValidator.IValidateType.VALID,sMsg,isGlobalMsg);
        }

        return bValid;
    }
    public void addValidate(int iId,byte byValidateType,byte byControlType,byte byEventType)
    {
        CLValidateFieldDTO clValidateFieldDTO = new CLValidateFieldDTO();
        clValidateFieldDTO.setFieldId(iId);
        clValidateFieldDTO.setControlType(byControlType);
        clValidateFieldDTO.setEventType(byEventType);
        clValidateFieldDTO.setValidateType(byValidateType);

        hsValidateFields.put(iId,clValidateFieldDTO);

    }
    public boolean validate(Activity clActivity)
    {
        boolean bValid = true;
        if(hsValidateFields != null && hsValidateFields.size() > 0)
        {
            TextView clTextView = null;
            CLValidateFieldDTO clValidateFieldDTO = null;

            for (Object key : hsValidateFields.keySet())
            {
                clTextView = (TextView) clActivity.findViewById(Integer.parseInt(key.toString()));
                clValidateFieldDTO  = hsValidateFields.get(key);

                if(clValidateFieldDTO.getValidateType() == IValidator.IValidateType.MANDATORY)
                    bValid = checkMandatory(clTextView, null);
                else if(clValidateFieldDTO.getValidateType() == IValidator.IValidateType.VALID)
                {
                    if (clValidateFieldDTO.getControlType() == IConstants.IControlType.DATE_PICKER)
                    {
                        bValid = checkDate(clTextView, null);
                    }
                    else if (clValidateFieldDTO.getControlType() == IConstants.IControlType.TIME_PICKER)
                    {
                        bValid = checkDate(clTextView, null);
                    }
                    else if (clValidateFieldDTO.getControlType() == IConstants.IControlType.EMAIL)
                    {
                        bValid = checkEMail(clTextView, null);
                    }
                    else if (clValidateFieldDTO.getControlType() == IConstants.IControlType.PHONE)
                    {
                        bValid = checkPhoneNo(clTextView, null);
                    }
                    else if (clValidateFieldDTO.getControlType() == IConstants.IControlType.WEBSITE)
                    {
                        bValid = checkWebsite(clTextView, null);
                    }
                }

            }


        }
        return bValid;
    }
    public String getJsonString(ViewGroup clView)
    {
        String sJsonString = null;
        if(clView != null)
        {
            byte byChildCount = (byte)clView.getChildCount();//todo byte
            if(byChildCount > 0)
            {
                View clChildLayout = null;
                for (byte byIndex = 0; byIndex < byChildCount; byIndex++)
                {
                    clChildLayout = clView.getChildAt(byIndex);
                    if(clChildLayout instanceof LinearLayout
                            || clChildLayout instanceof RelativeLayout
                            || clChildLayout instanceof FrameLayout)
                    {

                       if(clChildLayout instanceof LinearLayout)
                       {

                       }
                        else if(clChildLayout instanceof RelativeLayout)
                       {

                       }
                        else
                       {

                       }
                    }
                    else
                    {

                    }

                }
            }
        }

        return null;
    }
    private static  void setError(TextView clTextView,byte byValidateType,String sMsg,boolean isGlobalMsg)
    {
        CharSequence chHint  = clTextView.getHint();
        if (sMsg != null && trim(sMsg).length() > 0)
            clTextView.setError(sMsg);
        else if(chHint != null && trim(chHint.toString()).length() > 0)
            clTextView.setError(byValidateType==IValidator.IValidateType.MANDATORY?chHint+" is mandatory":chHint+" is invalid");// move to xml
        else
            clTextView.setError(byValidateType==IValidator.IValidateType.MANDATORY?"Value is mandatory":"Value is invalid");// move to xml
        clTextView.requestFocus();

    }
    private static boolean  checkPattern(String sPattern,String sValue)
    {
        return Pattern.compile(sPattern).matcher(sValue).matches();
    }
    private static  String getComparisonMsg(String sLabel1,String sLabel2,boolean isEqualValuesAllowed)
    {
        if(isEqualValuesAllowed)
            return sLabel1+" greater than or equal to "+sLabel2;
        else
            return sLabel1+" greater than to "+sLabel2;
    };
    private static String trim(String sValue)
    {
        if(sValue != null)
            sValue = sValue.trim();
        return sValue;
    }

}
